#first make directory data
$ mkdir data
#first make server,client and gen.sh executable...
#generate n files starting from 1 usig gen.sh
$ ./gen.sh 1 n
#start the server....
$ ./server <port no>
#start client program.... 
$ ./client <IP> <port no> <no of concurrent clients >
#no of concurent clients should be less than no of files created using ./gen.sh

